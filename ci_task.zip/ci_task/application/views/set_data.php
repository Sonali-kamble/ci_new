

<form action="<?php echo base_url('/user/setsession') ?>" method="post">
Name: <input type="text" name="username">
<br/>
<input type="submit" name="submit" value="Add">
</form> 